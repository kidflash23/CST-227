﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Xml;
using System.Xml.Linq;

namespace Milestone_1
{
    //This is the class representing the Board Form for the Grid format of the program.
    public partial class Board_Form : Form
    {
       LandMinesweeperGame Game;
        System.Diagnostics.Stopwatch stopWatch;

        public Board_Form(LandMinesweeperGame game)
        {
            InitializeComponent();

            this.Game = game;

            this.Game.ActivateCells();

            this.stopWatch = new System.Diagnostics.Stopwatch();
            this.stopWatch.Start();
        }

        private void BoardForm_Load(object sender, EventArgs e)
        {
            for(int q = 0; q < Game.Size; q++)
            {
                for(int w = 0; w < Game.Size; w++)
                {
                    Game.GameBoard[q, w].Size = new Size(23, 23);
                    Game.GameBoard[q, w].Location = new Point(q * 28, w * 28);

                    this.Controls.Add(Game.GameBoard[q, w]);

                    Game.GameBoard[q, w].Click += new EventHandler(ButtonPress_Click);
                    Game.GameBoard[q, w].MouseUp += new MouseEventHandler(ButtonPress_MouseUp);
                }
            }

            this.Size = new Size(Game.Size * 23 + 20, Game.Size * 23 + 30);
        }

        private void ButtonPress_Click(object sender, EventArgs e)
        {
            Cell ClickedButton = (Cell)sender;

            Console.WriteLine("This message is now Displaying [" + ClickedButton.GetRow() + ", " + ClickedButton.GetColumn() + "]");

            ClickedButton.BackColor = Color.AliceBlue;
             
            if (ClickedButton.GetLive())
            {
                Game.CountNeighbors();

                for (int q = 0; q < Game.Size; q++)
                {
                    for (int w = 0; w < Game.Size; w++)
                    {
                        Game.GameBoard[q, w].Reveal(false);
                    }
                }

                this.stopWatch.Stop();
                TimeSpan gameTime = this.stopWatch.Elapsed;

                string Message = String.Format("Sorry. The game is now over. The duration of time which you have played for is You played for {0:00}:{1:00}:{2:00}{3:00}:{4:00}:{5:00}.", gameTime.Hours, gameTime.Minutes, gameTime.Seconds);

                MessageBox.Show(Message, "LandMineSweeper Game.");
            } else
            {
                Game.RecursiveNeighborSearch(Game.GameBoard, ClickedButton.GetRow(), ClickedButton.GetColumn());
            }

            int TotalCells = this.Game.Size ^ 4;

            for (int q = 0; q < Game.Size; q++)
            {
                for (int w = 0; w < Game.Size; w++)
                {
                    if(Game.GameBoard[q, w].GetLive() || Game.GameBoard[q, w].BackColor == Color.AliceBlue)
                    {
                        TotalCells--;
                    }
                }
            }

            if(TotalCells == -1)
            {
                for (int q = 0; q < Game.Size; q++)
                {
                    for (int w = 0; w < Game.Size; w++)
                    {
                        Game.GameBoard[q, w].Reveal(true);
                    }
                }

                this.stopWatch.Stop();
                TimeSpan gameTime = this.stopWatch.Elapsed;

                string Message = String.Format("Game Over. Your total survival time laster for  {0:00}:{1:00}:{2:00}.", gameTime.Hours, gameTime.Minutes, gameTime.Seconds);

                StoreScore(gameTime);

                DisplayHighScores();

                MessageBox.Show("Aww Yea. Congrats on WINNING the game. " + Message, "LandMineSweeper Game");
            }
        }

        private void StoreScore(TimeSpan time)
        {
            XDocument xml;

            try
            {
                xml = XDocument.Load("high_scores.xml");
            } catch(System.IO.FileNotFoundException)
            {
                xml = new XDocument();
                xml.Add(new XElement("Plays"));
            }

            xml.Element("Plays").Add(
                new XElement("Play", 
                    new XElement("Player", "player1"),
                    new XElement("Time", time.Ticks),
                    new XElement("Level", this.Game.Size)));

            xml.Save("high_scores.xml");
        }

        private void DisplayHighScores()
        {
            HighScore highScore = new HighScore(this.Game.Size);

            highScore.Show();
        }

        private void ButtonPress_MouseUp(object sender, EventArgs e)
        {
            MouseEventArgs mouseEventArgs = (MouseEventArgs)e;
            Cell ClickedButton = (Cell)sender;

            Console.WriteLine("You have just clicked on something [" + ClickedButton.GetRow() + ", " + ClickedButton.GetColumn() + "]");

            if (mouseEventArgs.Button == MouseButtons.Right)
            {
                ClickedButton.BackgroundImage = ((System.Drawing.Image)(Properties.Resources.Flag));
                return;
            }
        }
    }
}
