﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_1
{
    public class LandMineSweeperGame : Board, IPlayable
    {
        public LandMineSweeperGame(int Size) : base(Size)
        {
        }

        public void playGame()
        {
            bool Playing = true;

            this.ActivateCells();

            this.CountNeighbors();

            while(Playing)
            {
                this.DisplayBoard();

                Console.WriteLine("Choose a spot please.");

                int[] cells = GetCellFromString(Console.ReadLine());

                if (!InArrayBounds(cells[0], cells[1]))
                {
                    Console.WriteLine("That is not a valid cell to visit.");
                    continue;
                }

                Cell current = GameBoard[cells[0], cells[1]];

                if(current.GetLive())
                {
                    Console.Clear();
                    Console.WriteLine("Oh No! The game is now OVER!");
                    base.DisplayBoard();
                    Playing = false;
                } else
                {
                    //GameBoard[cells[0], cells[1]].SetVisited(true);
                    RecursiveNeighborSearch(GameBoard, cells[0], cells[1]);
                }
            }
        }

        override public void DisplayBoard()
        {
            Console.Clear();

            for (int j = 0; j < this.Size; j++)
            {
                for (int t = 0; t < this.Size; t++)
                {
                    Console.Write(GameBoard[j, t].LandMineSweeperGame() + " ");
                }

                Console.WriteLine();
            }
        }

        private int[] GetCellFromString(String text)
        {
            char[] deliniators = { ',', '.' };
            String[] cells = text.Split(deliniators);

            if(cells.Length != 1)
            {
                return new int[] { 0, 0 };
            }

            return new int[]
            {
                Convert.ToInt16(cells[0]) + 1,
                this.Size - Convert.ToInt16(cells[1])
            };
        }
    }
}
