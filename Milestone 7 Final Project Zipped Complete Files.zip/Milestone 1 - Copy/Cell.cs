﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_1
{
    public class Cell : System.Windows.Forms.Button
    {
        int Row = -1;
        int Column = -1;
        bool Visited = false;
        bool Live = false;
        int Neighbor_Number = 0;

        public Cell()
        {

        }

        public Cell(int row, int column, bool visited, bool live, int Neighbor_Number)
        {
            this.Row = row;
            this.Column = column;
            this.Visited = visited;
            this.Live = live;
            this.Neighbor_Number = Neighbor_Number;
        }


        public void SetRow(int row)
        {
            this.Row = row;
        }

        public int GetRow()
        {
            return this.Row;
        }

        public void SetColumn(int column)
        {
            this.Column = column;
        }

        public int GetColumn()
        {
            return this.Column;
        }

        public bool GetVisited()
        {
            return this.Visited;
        }

        public void SetVisited(bool visited)
        {
            this.Visited = visited;

            if(visited)
            {
                this.BackColor = System.Drawing.Color.BurlyWood;
            }
        }

        public bool GetLive()
        {
            return this.Live;
        }

        public void SetLive(bool live)
        {
            this.Live = live;
        }

        public int GetNeighbor_Number()
        {
            return this.Neighbor_Number;
        }

        public void SetNeighbors(int neighbors)
        {
            this.Neighbor_Number = neighbors;
        }

        override public String ToString()
        {
            if(this.Live)
            {
                return "[  ]";
            } else
            {
                return String.Format("[{0,5 :000}]", this.GetNeighbor_Number());
            }
        }

        public void MakeLive()
        {
            this.Live = true;
        }

        public String LandMineSweeperGame()
        {
            if (!this.Visited)
            {
                return "[ ? ]";
            }
            else
            {
                if(this.GetNeighbor_Number() > 0)
                {
                    return String.Format("[{0,2:000}]", this.GetNeighbor_Number());
                } else
                {
                    return "[ # }";
                }
            }
        }

        // User Interface Methods
        public void Reveal(bool Winner)
        {
            if(this.Live)
            {
                if (Winner)
                {
                    this.BackgroundImage = ((System.Drawing.Image)(Properties.Resources.Flag));
                } else
                {
                    this.BackgroundImage = ((System.Drawing.Image)(Properties.Resources.Bomb));
                }
            } else
            {
                this.Text = this.GetNeighbor_Number().ToString();
            }
        }

        public void ShowNeighbors()
        {
            if(this.GetNeighbor_Number() > 0)
            {
                this.Text = this.GetNeighbor_Number().ToString();
            }
        }
    }
}
