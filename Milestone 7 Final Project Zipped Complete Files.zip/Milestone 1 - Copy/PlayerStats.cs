﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Milestone_1
{  
    class PlayerStats : IComparable<PlayerStats>
    {
        public string Player { get; set; }
        public int Level { get; set; }
        public long Time { get; set; }

        //This shows the PlayerStats and displays the variables.
        public PlayerStats(string Player, int Level, long Time)
        { 
            this.Player = Player;
            this.Time = Time;
            this.Level = Level;
        }

        public int CompareTo(PlayerStats that)
        {
            if(this.Time < that.Time)
            {
                return -1;
            } else if(this.Time > that.Time)
            {
                return 1;
            }

            return 0;
        }


        //This gets the number of ticks for the average time span of duration within the PlayerStats. 
        public TimeSpan GetTimeSpan()
        {
            return TimeSpan.FromTicks(this.Time);
        }
    }
}
